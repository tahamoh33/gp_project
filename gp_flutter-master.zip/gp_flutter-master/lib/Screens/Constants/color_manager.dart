import 'package:flutter/material.dart';

class ColorManager {
  static const Color primary = Color(0xff1a74d7);
  static const Color primaryLight = Color(0xfff1f4fd);
  static const Color gray = Color(0xffeaebeb);
}
