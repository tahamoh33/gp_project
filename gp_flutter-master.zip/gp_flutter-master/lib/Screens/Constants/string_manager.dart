class StringManager {
  static String uId = '';
}
