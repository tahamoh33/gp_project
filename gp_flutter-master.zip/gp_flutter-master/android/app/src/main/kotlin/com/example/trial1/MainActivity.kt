package com.example.trial1

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
